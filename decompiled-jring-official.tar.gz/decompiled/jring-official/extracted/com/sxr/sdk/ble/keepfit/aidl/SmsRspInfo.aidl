package com.sxr.sdk.ble.keepfit.aidl;

parcelable SmsRspInfo;